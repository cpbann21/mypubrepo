#########################################################################
	Ansible playbook to apply CIS guidelines on Amazon Linux
#########################################################################

Perform a Local run:

	ansible-playbook -i "localhost," -c local playbook.yml  --extra-vars "access_key=<AWS Access Key> secret_key=<AWS Secret Key> home_volume=10 log_tmp_volume=10"


#### Example Snippet in playbook.yml

    - name: 5.2.14 Ensure SSH LoginGraceTime is set to one minute or less
      lineinfile:
        dest: /etc/ssh/sshd_config
        regexp: 'LoginGraceTime'
        line: 'LoginGraceTime 60'


